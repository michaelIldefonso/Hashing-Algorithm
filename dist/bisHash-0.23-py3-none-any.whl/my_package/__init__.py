# hashing/__init__.py

from .hashing import bis_hash


__all__ = ["bis_Hash"]